# Libreria HMC5883L_3Axi
[![license](https://www.pinguytaz.net/IMG_GITHUB/gplv3-with-text-84x42.png)](https://github.com/pinguytaz/MiBADUSB/blob/master/LICENSE)


__HMC5883L_3Axi es un proyecto de código abierto con el unico fin de educación e investigación, en el uso del sensor de campo magnetico para su uso en Arduino.

## Posible usos del sen sor HMC5883L
Las aplicaciones de este sensor son diversa, en especial si los juntamos con un sensor de gravedad, algunos
usos que se proponen son:
1.- **Brujuja** 
   La información recogida de esta se podra enviar a un movil por Bluetooth a un movil
2.- **Realidad Virtual** 
   Aprovechando la información obtenida de sus tres ejes podremos enviar esta información a un dispositivo que nos permitira
saber donde esta mirando nuestro equipo.

__Website__: https://www.pinguytaz.net
   

